/* str_io.c
 *	Simple program to test whether the systemcall interface works.
 *
 *	Just do a syscall that read a string and print it
 *
 */

#include "syscall.h"
char a[256];
int main() {
    
    int pid,i=10;
    
    PrintString("Program1\n");

    pid= Exec("srinivas",10);
    // PrintString("String length: (<= 255):\n");
    // ReadString(a, ReadNum());
    Join(pid);
    SrinivasSleep(10);
    pid = 0;
   
    
    // Exec("srinivas", 0);
    PrintNum(VFork());   //this line denotes 
    PrintString("\n");
    PrintNum(VFork());
    PrintString("\n");
    PrintNum(VFork());

    PrintString("\n");

    while(i<0){i--;}
    // while(1) PrintUC("3");
    
}
