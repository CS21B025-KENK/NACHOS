

#include "syscall.h"
char a[256];
int main() {
    int a;
    a=0;
    while(a++<1000){
    PrintUC("2");
    // a++;
    }
 

}
